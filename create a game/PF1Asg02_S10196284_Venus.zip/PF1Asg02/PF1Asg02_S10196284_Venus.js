(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"PF1Asg02_S10196284_Venus_atlas_", frames: [[0,0,1607,1576]]},
		{name:"PF1Asg02_S10196284_Venus_atlas_2", frames: [[0,0,1602,1205]]},
		{name:"PF1Asg02_S10196284_Venus_atlas_3", frames: [[0,0,1602,1202]]},
		{name:"PF1Asg02_S10196284_Venus_atlas_4", frames: [[0,0,1602,1202]]},
		{name:"PF1Asg02_S10196284_Venus_atlas_5", frames: [[0,0,1602,1202]]},
		{name:"PF1Asg02_S10196284_Venus_atlas_6", frames: [[0,0,1602,1202]]},
		{name:"PF1Asg02_S10196284_Venus_atlas_7", frames: [[0,0,1602,1202]]},
		{name:"PF1Asg02_S10196284_Venus_atlas_8", frames: [[0,0,1602,1202]]},
		{name:"PF1Asg02_S10196284_Venus_atlas_9", frames: [[0,0,1602,1202]]},
		{name:"PF1Asg02_S10196284_Venus_atlas_10", frames: [[0,0,1602,1202]]},
		{name:"PF1Asg02_S10196284_Venus_atlas_11", frames: [[0,0,1602,1202]]},
		{name:"PF1Asg02_S10196284_Venus_atlas_12", frames: [[0,0,1602,1202]]},
		{name:"PF1Asg02_S10196284_Venus_atlas_13", frames: [[0,0,1602,1202]]},
		{name:"PF1Asg02_S10196284_Venus_atlas_14", frames: [[0,0,1602,1202]]},
		{name:"PF1Asg02_S10196284_Venus_atlas_15", frames: [[0,0,1602,1202]]},
		{name:"PF1Asg02_S10196284_Venus_atlas_16", frames: [[0,0,1600,1200]]},
		{name:"PF1Asg02_S10196284_Venus_atlas_17", frames: [[0,0,1600,1200]]},
		{name:"PF1Asg02_S10196284_Venus_atlas_18", frames: [[0,0,1600,1200]]},
		{name:"PF1Asg02_S10196284_Venus_atlas_19", frames: [[0,0,1600,1200]]},
		{name:"PF1Asg02_S10196284_Venus_atlas_20", frames: [[0,0,1600,1200]]},
		{name:"PF1Asg02_S10196284_Venus_atlas_21", frames: [[0,0,1600,1200]]},
		{name:"PF1Asg02_S10196284_Venus_atlas_22", frames: [[0,1830,519,108],[1294,1783,53,52],[521,1830,402,112],[1217,1461,104,73],[1225,1202,331,92],[1266,1722,48,59],[878,1526,43,102],[1558,1202,191,141],[878,1202,191,141],[1044,1484,77,86],[1123,1484,77,86],[1071,1202,122,141],[1093,1345,122,137],[878,1449,164,75],[985,1526,49,102],[878,1345,213,102],[846,1944,377,102],[1225,1633,39,80],[1026,1669,39,80],[1525,1420,58,87],[1171,1751,39,78],[1067,1669,39,80],[1323,1461,39,95],[1007,1751,39,80],[1705,1434,39,95],[1585,1508,39,95],[1202,1536,39,95],[1243,1536,39,95],[1626,1508,39,95],[1465,1509,39,95],[1506,1509,39,95],[1364,1519,39,80],[1497,1345,220,73],[1405,1519,39,80],[925,1526,58,87],[1048,1751,39,78],[1366,1601,39,78],[1089,1751,39,78],[925,1615,58,86],[1130,1751,39,78],[1407,1601,39,78],[1048,1831,39,78],[1007,1833,39,78],[1225,1296,270,88],[1585,1420,58,86],[1108,1669,39,80],[1149,1669,39,80],[1719,1345,58,87],[1089,1831,39,78],[1284,1558,39,80],[1036,1572,39,95],[1325,1601,39,80],[985,1630,39,95],[938,1703,39,95],[1217,1386,158,73],[1077,1572,39,95],[1118,1572,39,95],[1159,1572,39,95],[925,1800,39,95],[966,1800,39,95],[1266,1640,39,80],[1225,1715,39,80],[1465,1420,58,87],[1130,1831,39,78],[1171,1831,39,78],[414,1944,430,93],[1212,1797,39,78],[1645,1420,58,86],[1225,1877,39,78],[1253,1797,39,78],[1225,1957,39,78],[1266,1877,39,78],[878,1703,58,86],[1377,1386,86,131],[0,1202,876,626],[0,1940,412,98],[0,0,1600,1200]]}
];


// symbols:



(lib.CachedTexturedBitmap_10 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_100 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_101 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_19"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_102 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_13"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_103 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_16"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_104 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_4"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_105 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_15"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_106 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_5"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_11 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_110 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_111 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_113 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_114 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_3"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_12 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_10"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_13 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_14 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_15 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_19 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_23 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_24 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_28 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_29 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_3 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_30 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_7"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_31 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_32 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_33 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_34 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_35 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_36 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_37 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_38 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_39 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_40 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_41 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_42 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_43 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_44 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_45 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_46 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_47 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_48 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_49 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_5 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_50 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_51 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_52 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_53 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_54 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_55 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_56 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_57 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_58 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_59 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_6 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_60 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_61 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_62 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_63 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_64 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_65 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_66 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_67 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_68 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_69 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_7 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_70 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_71 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_72 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_73 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_74 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_75 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(60);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_76 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(61);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_77 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(62);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_78 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(63);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_79 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(64);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_8 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(65);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_80 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(66);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_81 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(67);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_82 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(68);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_83 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(69);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_84 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(70);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_85 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(71);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_86 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(72);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_87 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(73);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_88 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_11"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_89 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(74);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_9 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(75);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_90 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_8"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_91 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_20"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_92 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_9"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_93 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_18"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_94 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_12"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_95 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_21"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_96 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_14"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_97 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_22"]);
	this.gotoAndStop(76);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_98 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_6"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_99 = function() {
	this.initialize(ss["PF1Asg02_S10196284_Venus_atlas_17"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.starField = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_89();
	this.instance.parent = this;
	this.instance.setTransform(49.9,19.2,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.starField, new cjs.Rectangle(49.9,19.2,438,313), null);


(lib.starField2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_88();
	this.instance.parent = this;
	this.instance.setTransform(-0.5,-0.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.starField2, new cjs.Rectangle(-0.5,-0.5,801,601), null);


(lib.star2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_87();
	this.instance.parent = this;
	this.instance.setTransform(-0.5,-0.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.star2, new cjs.Rectangle(-0.5,-0.5,43,65.5), null);


(lib.spaceCorridor2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_86();
	this.instance.parent = this;
	this.instance.setTransform(98.7,239.75,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_85();
	this.instance_1.parent = this;
	this.instance_1.setTransform(20.2,243.25,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_84();
	this.instance_2.parent = this;
	this.instance_2.setTransform(39.75,243.25,0.5,0.5);

	this.instance_3 = new lib.CachedTexturedBitmap_83();
	this.instance_3.parent = this;
	this.instance_3.setTransform(59.3,243.25,0.5,0.5);

	this.instance_4 = new lib.CachedTexturedBitmap_82();
	this.instance_4.parent = this;
	this.instance_4.setTransform(78.85,243.25,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_81();
	this.instance_5.parent = this;
	this.instance_5.setTransform(98.5,295,0.5,0.5);

	this.instance_6 = new lib.CachedTexturedBitmap_80();
	this.instance_6.parent = this;
	this.instance_6.setTransform(20,298.5,0.5,0.5);

	this.instance_7 = new lib.CachedTexturedBitmap_79();
	this.instance_7.parent = this;
	this.instance_7.setTransform(39.55,298.5,0.5,0.5);

	this.instance_8 = new lib.CachedTexturedBitmap_78();
	this.instance_8.parent = this;
	this.instance_8.setTransform(59.1,298.5,0.5,0.5);

	this.instance_9 = new lib.CachedTexturedBitmap_77();
	this.instance_9.parent = this;
	this.instance_9.setTransform(18.1,465,0.5,0.5);

	this.instance_10 = new lib.CachedTexturedBitmap_76();
	this.instance_10.parent = this;
	this.instance_10.setTransform(50.8,466.65,0.5,0.5);

	this.instance_11 = new lib.CachedTexturedBitmap_75();
	this.instance_11.parent = this;
	this.instance_11.setTransform(72.85,466.65,0.5,0.5);

	this.instance_12 = new lib.CachedTexturedBitmap_74();
	this.instance_12.parent = this;
	this.instance_12.setTransform(91.95,403.2,0.5,0.5);

	this.instance_13 = new lib.CachedTexturedBitmap_73();
	this.instance_13.parent = this;
	this.instance_13.setTransform(24.45,403.2,0.5,0.5);

	this.instance_14 = new lib.CachedTexturedBitmap_72();
	this.instance_14.parent = this;
	this.instance_14.setTransform(46.95,403.2,0.5,0.5);

	this.instance_15 = new lib.CachedTexturedBitmap_71();
	this.instance_15.parent = this;
	this.instance_15.setTransform(69.45,403.2,0.5,0.5);

	this.instance_16 = new lib.CachedTexturedBitmap_70();
	this.instance_16.parent = this;
	this.instance_16.setTransform(91.95,352.1,0.5,0.5);

	this.instance_17 = new lib.CachedTexturedBitmap_69();
	this.instance_17.parent = this;
	this.instance_17.setTransform(24.45,352.1,0.5,0.5);

	this.instance_18 = new lib.CachedTexturedBitmap_68();
	this.instance_18.parent = this;
	this.instance_18.setTransform(46.95,352.1,0.5,0.5);

	this.instance_19 = new lib.CachedTexturedBitmap_67();
	this.instance_19.parent = this;
	this.instance_19.setTransform(68.55,526.05,0.5,0.5);

	this.instance_20 = new lib.CachedTexturedBitmap_66();
	this.instance_20.parent = this;
	this.instance_20.setTransform(69.45,352.1,0.5,0.5);

	this.instance_21 = new lib.CachedTexturedBitmap_65();
	this.instance_21.parent = this;
	this.instance_21.setTransform(46.05,526.05,0.5,0.5);

	this.instance_22 = new lib.CachedTexturedBitmap_64();
	this.instance_22.parent = this;
	this.instance_22.setTransform(78.65,298.5,0.5,0.5);

	this.instance_23 = new lib.CachedTexturedBitmap_63();
	this.instance_23.parent = this;
	this.instance_23.setTransform(16.35,521.75,0.5,0.5);

	this.instance_24 = new lib.CachedTexturedBitmap_62();
	this.instance_24.parent = this;
	this.instance_24.setTransform(94.9,466.65,0.5,0.5);

	this.instance_25 = new lib.CachedTexturedBitmap_61();
	this.instance_25.parent = this;
	this.instance_25.setTransform(91.05,526.05,0.5,0.5);

	this.instance_26 = new lib.CachedTexturedBitmap_60();
	this.instance_26.parent = this;
	this.instance_26.setTransform(672.05,318.8,0.5,0.5);

	this.instance_27 = new lib.CachedTexturedBitmap_59();
	this.instance_27.parent = this;
	this.instance_27.setTransform(760.05,319.05,0.5,0.5);

	this.instance_28 = new lib.CachedTexturedBitmap_58();
	this.instance_28.parent = this;
	this.instance_28.setTransform(740.5,319.05,0.5,0.5);

	this.instance_29 = new lib.CachedTexturedBitmap_57();
	this.instance_29.parent = this;
	this.instance_29.setTransform(720.95,319.05,0.5,0.5);

	this.instance_30 = new lib.CachedTexturedBitmap_56();
	this.instance_30.parent = this;
	this.instance_30.setTransform(701.4,319.05,0.5,0.5);

	this.instance_31 = new lib.CachedTexturedBitmap_55();
	this.instance_31.parent = this;
	this.instance_31.setTransform(672.25,263.55,0.5,0.5);

	this.instance_32 = new lib.CachedTexturedBitmap_54();
	this.instance_32.parent = this;
	this.instance_32.setTransform(760.25,263.8,0.5,0.5);

	this.instance_33 = new lib.CachedTexturedBitmap_53();
	this.instance_33.parent = this;
	this.instance_33.setTransform(740.7,263.8,0.5,0.5);

	this.instance_34 = new lib.CachedTexturedBitmap_52();
	this.instance_34.parent = this;
	this.instance_34.setTransform(721.15,263.8,0.5,0.5);

	this.instance_35 = new lib.CachedTexturedBitmap_51();
	this.instance_35.parent = this;
	this.instance_35.setTransform(752.5,92.8,0.5,0.5);

	this.instance_36 = new lib.CachedTexturedBitmap_50();
	this.instance_36.parent = this;
	this.instance_36.setTransform(729.45,94.9,0.5,0.5);

	this.instance_37 = new lib.CachedTexturedBitmap_49();
	this.instance_37.parent = this;
	this.instance_37.setTransform(707.4,94.9,0.5,0.5);

	this.instance_38 = new lib.CachedTexturedBitmap_48();
	this.instance_38.parent = this;
	this.instance_38.setTransform(688.3,150.6,0.5,0.5);

	this.instance_39 = new lib.CachedTexturedBitmap_47();
	this.instance_39.parent = this;
	this.instance_39.setTransform(755.8,150.6,0.5,0.5);

	this.instance_40 = new lib.CachedTexturedBitmap_46();
	this.instance_40.parent = this;
	this.instance_40.setTransform(733.3,150.6,0.5,0.5);

	this.instance_41 = new lib.CachedTexturedBitmap_45();
	this.instance_41.parent = this;
	this.instance_41.setTransform(710.8,150.6,0.5,0.5);

	this.instance_42 = new lib.CachedTexturedBitmap_44();
	this.instance_42.parent = this;
	this.instance_42.setTransform(688.3,201.7,0.5,0.5);

	this.instance_43 = new lib.CachedTexturedBitmap_43();
	this.instance_43.parent = this;
	this.instance_43.setTransform(755.8,201.7,0.5,0.5);

	this.instance_44 = new lib.CachedTexturedBitmap_42();
	this.instance_44.parent = this;
	this.instance_44.setTransform(733.3,201.7,0.5,0.5);

	this.instance_45 = new lib.CachedTexturedBitmap_41();
	this.instance_45.parent = this;
	this.instance_45.setTransform(711.7,35.5,0.5,0.5);

	this.instance_46 = new lib.CachedTexturedBitmap_40();
	this.instance_46.parent = this;
	this.instance_46.setTransform(710.8,201.7,0.5,0.5);

	this.instance_47 = new lib.CachedTexturedBitmap_39();
	this.instance_47.parent = this;
	this.instance_47.setTransform(734.2,35.5,0.5,0.5);

	this.instance_48 = new lib.CachedTexturedBitmap_38();
	this.instance_48.parent = this;
	this.instance_48.setTransform(701.6,263.8,0.5,0.5);

	this.instance_49 = new lib.CachedTexturedBitmap_37();
	this.instance_49.parent = this;
	this.instance_49.setTransform(754.25,36.05,0.5,0.5);

	this.instance_50 = new lib.CachedTexturedBitmap_36();
	this.instance_50.parent = this;
	this.instance_50.setTransform(685.35,94.9,0.5,0.5);

	this.instance_51 = new lib.CachedTexturedBitmap_35();
	this.instance_51.parent = this;
	this.instance_51.setTransform(689.2,35.5,0.5,0.5);

	this.instance_52 = new lib.CachedTexturedBitmap_34();
	this.instance_52.parent = this;
	this.instance_52.setTransform(-0.5,-0.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_52},{t:this.instance_51},{t:this.instance_50},{t:this.instance_49},{t:this.instance_48},{t:this.instance_47},{t:this.instance_46},{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.instance_41},{t:this.instance_40},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.spaceCorridor2, new cjs.Rectangle(-0.5,-0.5,801,602.5), null);


(lib.ShieldBar2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_31();
	this.instance.parent = this;
	this.instance.setTransform(-0.5,-0.5,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_32();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.5,-0.5,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_33();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-0.5,-0.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,188.5,51);


(lib.Rocket2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_15();
	this.instance.parent = this;
	this.instance.setTransform(-1.05,-1.05,1.058,1.058);

	this.instance_1 = new lib.CachedTexturedBitmap_19();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-1.05,-1.05,1.058,1.058);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},2).to({state:[{t:this.instance_1}]},2).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_1}]},1).wait(2));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(2).to({_off:false},0).wait(6));

	// Layer_2
	this.instance_2 = new lib.CachedTexturedBitmap_23();
	this.instance_2.parent = this;
	this.instance_2.setTransform(45.5,142.05,1.058,1.058);

	this.instance_3 = new lib.CachedTexturedBitmap_24();
	this.instance_3.parent = this;
	this.instance_3.setTransform(83.3,142.05,1.058,1.058);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).to({state:[{t:this.instance_3}]},2).to({state:[{t:this.instance_2}]},2).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).wait(2));

	// Layer_3
	this.instance_4 = new lib.CachedTexturedBitmap_28();
	this.instance_4.parent = this;
	this.instance_4.setTransform(41.5,35.55,1.058,1.058);

	this.instance_5 = new lib.CachedTexturedBitmap_29();
	this.instance_5.parent = this;
	this.instance_5.setTransform(29.8,45.1,1.058,1.058);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4}]}).to({state:[{t:this.instance_5}]},2).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,202.1,234.1);


(lib.meteor2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_14();
	this.instance.parent = this;
	this.instance.setTransform(-0.8,-0.8,0.8303,0.8303);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.meteor2, new cjs.Rectangle(-0.8,-0.8,35.699999999999996,84.7), null);


(lib.heart2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_13();
	this.instance.parent = this;
	this.instance.setTransform(-1.1,-1.1,1.1482,1.1482);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.heart2, new cjs.Rectangle(-1.1,-1.1,55.1,67.8), null);


(lib.Bullet2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_11();
	this.instance.parent = this;
	this.instance.setTransform(-0.5,-0.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Bullet2, new cjs.Rectangle(-0.5,-0.5,26.5,26), null);


(lib.btnTutorial = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_10();
	this.instance.parent = this;
	this.instance.setTransform(-0.45,-0.45,0.4995,0.4995);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.4,-0.4,259.2,53.9);


(lib.btnStart = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_9();
	this.instance.parent = this;
	this.instance.setTransform(-0.45,-0.45,0.4995,0.4995);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.4,-0.4,205.8,48.9);


(lib.btnRestart = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_8();
	this.instance.parent = this;
	this.instance.setTransform(2.75,11.15,0.2916,0.2916);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(2.8,11.2,125.39999999999999,27.099999999999998);


(lib.btnMouse = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_7();
	this.instance.parent = this;
	this.instance.setTransform(27.5,6.4,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_6();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.5,-0.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,135,44);


(lib.btnKeyboard = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_5();
	this.instance.parent = this;
	this.instance.setTransform(12.2,6.4,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_6();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.5,-0.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,135,44);


(lib.btnBack = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_3();
	this.instance.parent = this;
	this.instance.setTransform(-0.45,-0.45,0.2862,0.2862);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.4,-0.4,46.9,21.4);


(lib.btnActivate = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_111();
	this.instance.parent = this;
	this.instance.setTransform(69,10.6,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_110();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.5,-0.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,201,56);


(lib.ttrScreen2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.star2();
	this.instance.parent = this;
	this.instance.setTransform(369.35,377,1,1,0,0,0,21.1,32.2);

	this.btnBack2 = new lib.btnBack();
	this.btnBack2.name = "btnBack2";
	this.btnBack2.parent = this;
	this.btnBack2.setTransform(-0.15,0.15,1.7467,1.7467,0,0,0,-0.1,0.1);
	new cjs.ButtonHelper(this.btnBack2, 0, 1, 1);

	this.instance_1 = new lib.meteor2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(369.4,297.05,0.6022,0.6022,0,0,0,31.6,77.2);

	this.instance_2 = new lib.heart2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(385.35,218,0.4355,0.4355,0,0,0,85.2,105.3);

	this.instance_3 = new lib.Bullet2();
	this.instance_3.parent = this;
	this.instance_3.setTransform(690.2,89.5,1,1,0,0,0,12.8,12.5);

	this.instance_4 = new lib.Rocket2();
	this.instance_4.parent = this;
	this.instance_4.setTransform(144.25,195.75,0.4726,0.4726,0,0,0,100.1,115.9);

	this.instance_5 = new lib.CachedTexturedBitmap_106();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-0.5,-0.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.btnBack2},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ttrScreen2, new cjs.Rectangle(-0.8,-0.8,801.3,601.3), null);


(lib.TitleScreen2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.btnTutorial2 = new lib.btnTutorial();
	this.btnTutorial2.name = "btnTutorial2";
	this.btnTutorial2.parent = this;
	this.btnTutorial2.setTransform(485.25,328.15,1.0011,0.999);
	new cjs.ButtonHelper(this.btnTutorial2, 0, 1, 1);

	this.btnStart2 = new lib.btnStart();
	this.btnStart2.name = "btnStart2";
	this.btnStart2.parent = this;
	this.btnStart2.setTransform(511.75,250.5,1.0011,0.999);
	new cjs.ButtonHelper(this.btnStart2, 0, 1, 1);

	this.instance = new lib.CachedTexturedBitmap_105();
	this.instance.parent = this;
	this.instance.setTransform(-0.5,-0.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.btnStart2},{t:this.btnTutorial2}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TitleScreen2, new cjs.Rectangle(-0.5,-0.5,801,601), null);


(lib.storypg0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.btnActivate = new lib.btnActivate();
	this.btnActivate.name = "btnActivate";
	this.btnActivate.parent = this;
	new cjs.ButtonHelper(this.btnActivate, 0, 1, 1);

	this.instance = new lib.CachedTexturedBitmap_113();
	this.instance.parent = this;
	this.instance.setTransform(296.5,26.05,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.btnActivate}]}).to({state:[{t:this.instance},{t:this.btnActivate}]},576).wait(1));

	// Layer_1
	this.instance_1 = new lib.CachedTexturedBitmap_90();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.5,-0.5,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_91();
	this.instance_2.parent = this;
	this.instance_2.setTransform(0,0,0.5,0.5);

	this.instance_3 = new lib.CachedTexturedBitmap_92();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-0.5,-0.5,0.5,0.5);

	this.instance_4 = new lib.CachedTexturedBitmap_93();
	this.instance_4.parent = this;
	this.instance_4.setTransform(0,0,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_94();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-0.5,-0.5,0.5,0.5);

	this.instance_6 = new lib.CachedTexturedBitmap_95();
	this.instance_6.parent = this;
	this.instance_6.setTransform(0,0,0.5,0.5);

	this.instance_7 = new lib.CachedTexturedBitmap_96();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-0.5,-0.5,0.5,0.5);

	this.instance_8 = new lib.CachedTexturedBitmap_97();
	this.instance_8.parent = this;
	this.instance_8.setTransform(0,0,0.5,0.5);

	this.instance_9 = new lib.CachedTexturedBitmap_98();
	this.instance_9.parent = this;
	this.instance_9.setTransform(-0.5,-0.5,0.5,0.5);

	this.instance_10 = new lib.CachedTexturedBitmap_99();
	this.instance_10.parent = this;
	this.instance_10.setTransform(0,0,0.5,0.5);

	this.instance_11 = new lib.CachedTexturedBitmap_100();
	this.instance_11.parent = this;
	this.instance_11.setTransform(-0.5,-0.5,0.5,0.5);

	this.instance_12 = new lib.CachedTexturedBitmap_101();
	this.instance_12.parent = this;
	this.instance_12.setTransform(0,0,0.5,0.5);

	this.instance_13 = new lib.CachedTexturedBitmap_102();
	this.instance_13.parent = this;
	this.instance_13.setTransform(-0.5,-0.5,0.5,0.5);

	this.instance_14 = new lib.CachedTexturedBitmap_103();
	this.instance_14.parent = this;
	this.instance_14.setTransform(0,0,0.5,0.5);

	this.instance_15 = new lib.CachedTexturedBitmap_104();
	this.instance_15.parent = this;
	this.instance_15.setTransform(-0.5,-0.5,0.5,0.5);

	this.instance_16 = new lib.CachedTexturedBitmap_114();
	this.instance_16.parent = this;
	this.instance_16.setTransform(-0.5,-0.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},35).to({state:[{t:this.instance_3}]},36).to({state:[{t:this.instance_4}]},36).to({state:[{t:this.instance_5}]},37).to({state:[{t:this.instance_6}]},36).to({state:[{t:this.instance_7}]},35).to({state:[{t:this.instance_8}]},37).to({state:[{t:this.instance_9}]},35).to({state:[{t:this.instance_10}]},36).to({state:[{t:this.instance_11}]},36).to({state:[{t:this.instance_12}]},37).to({state:[{t:this.instance_13}]},35).to({state:[{t:this.instance_14}]},36).to({state:[{t:this.instance_15}]},36).to({state:[{t:this.instance_16}]},37).wait(37));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,803.5,788);


(lib.screenChoose = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.btnMouse = new lib.btnMouse();
	this.btnMouse.name = "btnMouse";
	this.btnMouse.parent = this;
	this.btnMouse.setTransform(548.8,353.5);
	new cjs.ButtonHelper(this.btnMouse, 0, 1, 1);

	this.btnKeyboard = new lib.btnKeyboard();
	this.btnKeyboard.name = "btnKeyboard";
	this.btnKeyboard.parent = this;
	this.btnKeyboard.setTransform(137.65,353.5);
	new cjs.ButtonHelper(this.btnKeyboard, 0, 1, 1);

	this.instance = new lib.CachedTexturedBitmap_30();
	this.instance.parent = this;
	this.instance.setTransform(-0.5,-0.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.btnKeyboard},{t:this.btnMouse}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.screenChoose, new cjs.Rectangle(-0.5,-0.5,801,601), null);


(lib.gameOver2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.btnRestart2 = new lib.btnRestart();
	this.btnRestart2.name = "btnRestart2";
	this.btnRestart2.parent = this;
	this.btnRestart2.setTransform(449.05,483,1.7144,1.7144);
	new cjs.ButtonHelper(this.btnRestart2, 0, 1, 1);

	this.threeScore2 = new cjs.Text("", "25px 'Marker Felt'");
	this.threeScore2.name = "threeScore2";
	this.threeScore2.lineHeight = 29;
	this.threeScore2.lineWidth = 100;
	this.threeScore2.parent = this;
	this.threeScore2.setTransform(479.2,227.5);

	this.twoScore2 = new cjs.Text("", "25px 'Marker Felt'");
	this.twoScore2.name = "twoScore2";
	this.twoScore2.lineHeight = 29;
	this.twoScore2.lineWidth = 100;
	this.twoScore2.parent = this;
	this.twoScore2.setTransform(479.2,197.5);

	this.highScore2 = new cjs.Text("", "25px 'Marker Felt'");
	this.highScore2.name = "highScore2";
	this.highScore2.lineHeight = 29;
	this.highScore2.lineWidth = 100;
	this.highScore2.parent = this;
	this.highScore2.setTransform(479.2,166.35);

	this.yourScore2 = new cjs.Text("", "25px 'Marker Felt'");
	this.yourScore2.name = "yourScore2";
	this.yourScore2.lineHeight = 29;
	this.yourScore2.lineWidth = 100;
	this.yourScore2.parent = this;
	this.yourScore2.setTransform(479.2,105);

	this.instance = new lib.CachedTexturedBitmap_12();
	this.instance.parent = this;
	this.instance.setTransform(-0.5,-0.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.yourScore2},{t:this.highScore2},{t:this.twoScore2},{t:this.threeScore2},{t:this.btnRestart2}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.gameOver2, new cjs.Rectangle(-0.5,-0.5,801,601), null);


(lib.BulletBar2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bullet2();
	this.instance.parent = this;
	this.instance.setTransform(12.8,12.5,1,1,0,0,0,12.8,12.5);

	this.instance_1 = new lib.Bullet2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(12.8,12.5,1,1,0,0,0,12.8,12.5);

	this.instance_2 = new lib.Bullet2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(12.8,12.5,1,1,0,0,0,12.8,12.5);

	this.instance_3 = new lib.Bullet2();
	this.instance_3.parent = this;
	this.instance_3.setTransform(12.8,12.5,1,1,0,0,0,12.8,12.5);

	this.instance_4 = new lib.Bullet2();
	this.instance_4.parent = this;
	this.instance_4.setTransform(12.8,12.5,1,1,0,0,0,12.8,12.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance,p:{x:12.8}}]},1).to({state:[{t:this.instance_1,p:{x:12.8}},{t:this.instance,p:{x:71.75}}]},1).to({state:[{t:this.instance_2,p:{x:12.8}},{t:this.instance_1,p:{x:71.75}},{t:this.instance,p:{x:130.7}}]},1).to({state:[{t:this.instance_3,p:{x:12.8}},{t:this.instance_2,p:{x:71.75}},{t:this.instance_1,p:{x:130.7}},{t:this.instance,p:{x:189.65}}]},1).to({state:[{t:this.instance_4},{t:this.instance_3,p:{x:71.75}},{t:this.instance_2,p:{x:130.7}},{t:this.instance_1,p:{x:189.65}},{t:this.instance,p:{x:248.6}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,262.3,26);


// stage content:
(lib.PF1Asg02_S10196284_Venus = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		//create variables
		var c, w, h;
		var background;
		var game;
		var titleScreen, btnT, ttrS, btnB;
		var isPlaying;
		var hud;
		var shieldBar;
		var bulletBar
		var rocketA;
		var pointsDisplay;
		var startTime, timeDisplay;
		var clock;
		var meteorA, gameoverS, lifeA, starA;
		var startedBool = false;
		var i = 3;
		var p = 0;
		var timeLimit;
		var topScore = 0;
		var secondScore = 0;
		var thirdScore = 0;
		var yourScore = [ ];
		yourScore [0] = 0;
		//bullet
		var bullet;
		var dy2 = 15; // Vertical speed of bullet
		var acc = 0.4; // Acceleration of bullet
		var fire;
		var dist;
		var bullets = [];
		var whichBullet = 0; // Which bullet to shoot
		var maxNoOfBullets = 5; // Set number of bullets to shoot
		var dBullet =0;
		var storyPG;
		var story;
		var g = 15;
		var shootSound;
		var theSiren;
		var chooseS;
		var boolMouse = false;
		var handleMouseBool = false;
		
		
		
		//initialization function
		function init() {
			startedBool = false;
			handleMouseBool = false;
			
			boolMouse = false;
			//bullet
		    dist = 0; 
			 dy2 = 15; // Vertical speed of bullet
		acc = 0.4; // Acceleration of bullet
		fire;
			maxNoOfBullets = 5;
			dBullet = 0;
			bullets = [];
			whichBullet = 0;
			bullet;
			
		i = 3;
		p = 0;
			c = createjs;
			w = stage.canvas.width / window.devicePixelRatio;
			h = stage.canvas.height / window.devicePixelRatio;
			game = new c.Container();
			stage.addChild(game);
			buildBackground();
			
			
			c.Ticker.addEventListener("tick", gameLoop);
			g = 15;
			s = 10;
			dy2 = 15
			buildTitleScreen();
			titleScreen.btnStart2.addEventListener("click", pressStart);
			titleScreen.btnTutorial2.addEventListener("click", gotoTutorial);
			
			//console.log("initialize");
		
		}
		
		//call function
		init();
		
		//create background on stage
		//Container: group elements together
		function buildBackground() {
			background = new c.Container();
		
			stage.addChild(background);
		
			starField1 = new lib.starField2();
			starField1.x = 0;
			background.addChild(starField1);
		
			starField2 = new lib.starField2();
			starField1.x = 0;
			starField2.y = -h;
			background.addChild(starField2);
		
			
			spaceCorridor1 = new lib.spaceCorridor2();
			spaceCorridor1.x = 0;
			background.addChild(spaceCorridor1);
		
			spaceCorridor2 = new lib.spaceCorridor2();
			spaceCorridor2.x = 0;
			spaceCorridor2.y = -h;
			background.addChild(spaceCorridor2);
		
			 //console.log ("build background");
		}
		
		
		//game loop is being invoked by an event(tick)
		function gameLoop(e) {
			//game loop occurs here
		if(isPlaying) {
		currentTime = (new Date()).getTime();
		timeLimit = 60;
		    	//bullet
			moveBullets();
			
			
			if (rocketA.x>=w){
			rocketA.x=w;
		}
		
		if (rocketA.x<=0){
			rocketA.x=0;
		}
		
		if (rocketA.y>=h){
			rocketA.y=h;
		}
		
		if (rocketA.y<=0){
			rocketA.y=0;
		}
		
			performBackgroundMovements(s);
			performClockMovements(e);
		
			if (p % 5 == 0 && p>0){
				s += 1;
			    g += 1;
				dy2 += 1;
				//console.log ("s " + s);
				//console.log ("g " + g);
			}
		}
		//console.log ("game loop");
		}
		
		function performBackgroundMovements(speed) {
		 
			
			//move bg elements by an amount
			starField1.y += Math.floor(speed * 0.1);
			starField2.y += Math.floor(speed * 0.1);
			spaceCorridor1.y += Math.floor(speed * 0.2);
			spaceCorridor2.y += Math.floor(speed * 0.2);
		
		
			if (starField1.y >= h) {
				starField1.y = starField2.y - h;
			}
		
			if (starField2.y >= h) {
				starField2.y = starField1.y - h;
			}
		
			if (spaceCorridor1.y >= h) {
				spaceCorridor1.y = spaceCorridor2.y - h;
			}
		
			if (spaceCorridor2.y >= h) {
				spaceCorridor2.y = spaceCorridor1.y - h;
			}
		
		 //console.log ("perform background");
		}
		
		
		
		//Create an instance from the library and place it on the stage
		function buildTitleScreen(){
		titleScreen = new lib.TitleScreen2(); //takes the linkage fileTitle Screen in Library
		//set the location of TitleScreen
		titleScreen.x = 0;
		titleScreen.y = 0;
		stage.addChild(titleScreen);
			
		//console.log ("build titlescreen");
		}
		        
		
		function pressStart (evt) {
			titleScreen.visible = false;
			theSiren = createjs.Sound.createInstance("siren");
			theSiren.play();
			
			storyPG = new lib.storypg0();
			storyPG.x = 0;
			storyPG.y = 0;
			stage.addChild(storyPG);
			
			storyPG.btnActivate.addEventListener ("click", activateGame);
			//console.log ("story added");
		}
		
		//remove story
		function activateGame (){
			storyPG.gotoAndStop (0);
			stage.removeChild(storyPG);
			
			chooseS = new lib.screenChoose();
			chooseS.x = 0;
			chooseS.y = 0;
			stage.addChild(chooseS);
			
			chooseS.btnMouse.addEventListener ("click", useMouse);
			chooseS.btnKeyboard.addEventListener ("click", useKeyboard);
			
			//console.log ("story removed");
		
		}
		
		//player plays using mouse
		function useMouse (){
		stage.removeChild (chooseS);
		c.Ticker.addEventListener ("tick", foreverMouse);	
		    handleMouseBool = true;
			startedBool = true;
		    startGame ();
			
				
		   //console.log ("mouse gameplay");
		
		
		}
		
		
		//mouse loop
		function foreverMouse (){
			boolMouse = true;
			if (this.stage.mouseX > rocketA.x){
				rocketA.x  += g;
			}
			
			if (this.stage.mouseX < rocketA.x){
				rocketA.x -= g;
			}
			
			if (this.stage.mouseY > rocketA.y){
				rocketA.y += g;
			}
			
			if (this.stage.mouseY < rocketA.y){
				rocketA.y -= g;
			}
			
		
			//console.log ("mouseloop");
		}
		
		//shoot using mouse
		function handleMouseClick (){
			if (handleMouseBool == true && isPlaying){
				bullet = bullets[whichBullet];
				if (!bullet.isMoving) {
					bullet.x = rocketA.x + rocketA.nominalBounds.width/2;  // Place bullet at player position
					bullet.y = rocketA.y;
					bullet.dy2 = dy2;  // Bullet speed
					bullet.acc = acc;
					bullet.dist = 0;
					bullet.isMoving = true;
					
					background.addChild(bullet);
					whichBullet++;  // Move to next bullet
					dBullet++;
					console.log ("d increase" + d);
					
					
					shootSound = createjs.Sound.createInstance("breathe");
					shootSound.play();
					
					if (whichBullet >= maxNoOfBullets) {
						whichBullet = 0;  // Go back to first bullet.  Recycle.
						
						//console.log ("mouse gameplay shoot bullet");
					}
				}
			}
			
			
		}
		
		//player plays using keyboard
		function useKeyboard(){
			stage.removeChild (chooseS);
			document.onkeydown = keyPressed;
			
			startedBool = true;
			startGame ();
			//console.log ("keyboard gameplay");
		}
		
		function startGame() {
			//console.log (startedBool);
			
			if (startedBool == true){
				startTime = (new Date()).getTime();
		s = 10;
		isPlaying = true;
		
		
			if (handleMouseBool == true){ 
			stage.on("stagemousedown", handleMouseClick);
			}
				
				stage.removeChild(storyPG);
			buildHUD();
			c.Ticker.addEventListener("tick", startFall);
			spawnCharacter();
			spawnMeteors();
			spawnLife ();
			spawnStars ();
				//bullet
				createBullets(maxNoOfBullets);
			
		
			//grab current date and retrieve time
		startTime = (new Date()).getTime();
			//console.log (startTime);
			}
			
			//console.log ("game started");
		}
		
		
		
		function buildHUD(){
		hud = new c.Container();
		shieldBar = new lib.ShieldBar2();
		shieldBar.x = 10;
		shieldBar.y = 10;
		//set the initial state fullshields
		shieldBar.gotoAndStop(3);//stop at frame index 3
		hud.addChild(shieldBar);
			
		bulletBar = new lib.BulletBar2();
		bulletBar.x = 20;
		bulletBar.y = 80;
		//set the initial state fullshields
		bulletBar.gotoAndStop(5);//stop at frame index 3
		hud.addChild(bulletBar);	
			
		pointsDisplay = new c.Text(p, "28px Arial", "#FFFFFF");
		pointsDisplay.width = 100;
		pointsDisplay.x = w - 10;
		pointsDisplay.y = 5;
		pointsDisplay.textAlign = "right";
		hud.addChild(pointsDisplay);
			
			
		clock = new c.Text("", "14px Arial", "#000000");
			clock.width = 50;
			clock.x = w/2;
			clock.y = 5;
			clock.textAlign = "center";
			hud.addChild(clock);
			
		stage.addChild(hud);
		//console.log ("build hud");
		}
		
		
		
		function spawnCharacter()
		{
			rocketA = new lib.Rocket2();
			rocketA.x = w/3;
			rocketA.y = h - 200;
			background.addChild(rocketA);
			
			//console.log ("build character");
		}
		
		function performClockMovements(e){
		
			var time = Math.floor((currentTime - startTime)/1000);
			//console.log (time);
			clock.text = (timeLimit - time) + "s";
		
			if ((timeLimit - time) < 0){
				gameoverScreen ();
			}
		
			//console.log ("build clock");
		}
		
		// Function: Create bullets
		function createBullets(noOfBullets) {
			for (var b = 0; b < noOfBullets; b++) {
				bullet = new lib.Bullet2();
				bullet.dy2 = 0;  // Bullet speed
				bullet.acc = 0;
				bullet.isMoving = false;
				bullets.push(bullet);
			}
			
			console.log("No of bullets in array: " + bullets);
		}
		
		
		function keyPressed (e){
			
			if (e.keyCode == 65){//a key pressed
				rocketA.x -= g;
			}
			
			if (e.keyCode == 68){//d key pressed
				rocketA.x += g;
			}
			
			if (e.keyCode == 87){//w key pressed
				rocketA.y -= g;
			}
			
			if (e.keyCode == 83){//s key pressed
				rocketA.y += g;
			}
			
			if (e.keyCode == 32) { // Space key pressed
				bullet = bullets[whichBullet];
				if (!bullet.isMoving) {
					bullet.x = rocketA.x + rocketA.nominalBounds.width/2;  // Place bullet at player position
					bullet.y = rocketA.y;
					bullet.dy2 = dy2;  // Bullet speed
					bullet.acc = acc;
					bullet.dist = 0;
					bullet.isMoving = true;
					
					background.addChild(bullet);
					whichBullet++;  // Move to next bullet
					dBullet++;
					console.log ("d increase" + dBullet);
					
					
					shootSound = createjs.Sound.createInstance("breathe");
					shootSound.play();
					
					if (whichBullet >= maxNoOfBullets) {
						whichBullet = 0;  // Go back to first bullet.  Recycle.
						console.log ("keyboard shoot");
					}
				}
			}
			console.log ("keyboard gameplay");
		}
		
		function gotoTutorial () {
			ttrS = new lib.ttrScreen2();
			ttrS.x = 0;
			ttrS.y = 0;
			stage.addChild(ttrS);
			
			
			ttrS.btnBack2.addEventListener("click", gotoTitle);
			//console.log ("build tutorial page");
		}
		
		function gotoTitle(){
			//console.log("return")
			ttrS.visible = false;
			//console.log ("back to title");
		}
		
		function spawnMeteors (evt){
			meteorA = new lib.meteor2();
			meteorA.y = 0 - meteorA.nominalBounds.height;
			meteorA.x = Math.random() * 400;
			background.addChild(meteorA);    
			//console.log ("build obstacles");
		}
		
		function spawnStars (evt){
			starA = new lib.star2();
			starA.y = 0 - starA.nominalBounds.height;
			starA.x = Math.random() * 400;
			background.addChild(starA);    
			//console.log ("build points get");
		}
		
		function spawnLife (evt){
			lifeA = new lib.heart2();
			lifeA.y = 0 - lifeA.nominalBounds.height;
			lifeA.x = Math.random() * 400;
			background.addChild(lifeA);    
			//console.log ("build life get");
		}
		
		function startFall (evt) {
				var dy = g;
				meteorA.y += dy;
			lifeA.y += dy;
			starA.y += dy;
			
			if (meteorA.y > h + meteorA.nominalBounds.width) {
			meteorA.y = 0 - meteorA.nominalBounds.width;
			meteorA.x = Math.random() * 400;
			background.addChild(meteorA);    
			//console.log(meteorA.y);
		}
		
		if (lifeA.y > h + lifeA.nominalBounds.height) {
			lifeA.y = 0 - lifeA.nominalBounds.height;
			lifeA.x = Math.random() * 400;
			background.addChild(lifeA);    
			//console.log(lifeA.y);
		}
		
		if (starA.y > h + starA.nominalBounds.height) {
			starA.y = 0 - starA.nominalBounds.height;
			starA.x = Math.random() * 400;
			background.addChild(starA);    
			//console.log(starA.y);
		}
		
		minusShield ();
		addShield ();
		addPoints ();
		destroyMeteor ();
		
		//console.log ("start objects fall");
		
		}
		
		function minusShield () {
		         if (hitTestObject (rocketA, meteorA)){
					 meteorA.y = w + meteorA.nominalBounds.width;
					 i--;
					 //console.log ("shield " + i);
					shieldBar.gotoAndStop(i);
					 if (i <=0){
						 gameoverScreen ();
					 }
		
		}
		//console.log ("minus shield");
		}
		
		function addPoints () {
		         if (hitTestObject (rocketA, starA)){
					 starA.y = w + starA.nominalBounds.width;
					 p++;
					pointsDisplay.text = p;
					 return p;
		
		}
		//console.log ("add points");
		}
		
		
		function addShield () {
		         if (hitTestObject (rocketA, lifeA)){
					 lifeA.y = h + lifeA.nominalBounds.height;
					 i++;
					  if (i >= 3){
						i=3;
					  }
					 //console.log ("shield " + i);
					shieldBar.gotoAndStop(i);
				
		
		}
		//console.log ("add shield");
		}
		
		function destroyMeteor (){
			if (hitTestObject (bullet, meteorA)){
				meteorA.y = h + meteorA.nominalBounds.height;
				p += 2;
				pointsDisplay.text = p;
					 return p;
				console.log ("add 2");
			}
			
			if (dBullet>0){
				
				console.log ("bullets: " + (maxNoOfBullets-dBullet));
				bulletBar.gotoAndStop (maxNoOfBullets - dBullet);
				
				console.log ("minus 1")
				}
				
			//if (dBullet>=5 && !isPlaying ){
			//	d = 0;
				
			//}
			}
		
		
		function hitTestObject(obj1, obj2) {
			
			var hit = false;
			
		// Distance between objects
		var vx = (obj1.x + obj1.nominalBounds.width/2) - (obj2.x +
		obj2.nominalBounds.width/2);
		var vy = (obj1.y + obj1.nominalBounds.height/2) - (obj2.y +
		obj2.nominalBounds.height/2);
			
		//Figure out the combined half-widths and half-heights
		var combinedHalfWidths = obj1.nominalBounds.width/2 +
		obj2.nominalBounds.width/2;
		var combinedHalfHeights = obj1.nominalBounds.height/2 +
		obj2.nominalBounds.height/2;
			
		//Check for a collision on the x axis
		if (Math.abs(vx) < combinedHalfWidths) {
		//A collision might be occuring. Check for a collision on the y axis
		if (Math.abs(vy) < combinedHalfHeights) {
		//There's definitely a collision happening
		hit = true;
		}
		
		else {
		//There's no collision on the y axis
		hit = false;
		}
		}
		
		else {
		//There's no collision on the x axis
		hit = false;
		}
		
		return hit;
		// Code to detect collision
		}
		
		// Function: Move bullets
		function moveBullets() {
			// Move bullets
			// Make sure you use bullets.length in the for loop
			for (var b=0; b<bullets.length;b++) {
				if (bullets[b].isMoving) { 
					bullets[b].dy2 += bullets[b].acc; // Include acceleration
					bullets[b].y -= bullets[b].dy2; // Move bullet
					bullets[b].dist -= Math.abs(bullets[b].dy2);
					
					// Check if bullet goes beyond top of stage - remove bullet
					if (bullets[b].isMoving && bullets[b].dist > 500) { // any appropriate number
						bullets[b].dy2 = 0;
						bullets[b].acc = 0;
						bullets[b].dist = 0;
						bullets[b].isMoving = false;
						
						background.removeChild(bullets[b]);  // Remove bullet
					}
				}
			}
		}
		
		
		
		
		//end game
		function gameoverScreen () {
			c.Ticker.removeEventListener("tick", gameLoop);
			c.Ticker.removeEventListener("tick", startFall);
			stage.removeChild (background);
			
			c.Ticker.removeEventListener ("tick", foreverMouse);
			chooseS.btnMouse.removeEventListener ("click", useMouse);
			chooseS.btnKeyboard.removeEventListener ("click", useKeyboard);
			
			
			handleMouseBool = false;
			
			boolMouse = false;
			startedBool = false;
			isPlaying = false;
			theSiren = createjs.Sound.createInstance("siren");
			theSiren.play();
			gameoverS = new lib.gameOver2();
			gameoverS.y = 0;
			gameoverS.x = 0;
			stage.addChild(gameoverS);
			
			//display scores
			for (var a = 0; a < yourScore.length; a++){
				
				yourScore [a] = p;
			//Top 3 Scores 
						 if (yourScore [a] < topScore && yourScore [a] > secondScore && yourScore[a]>thirdScore){
						 thirdScore = secondScore;
						 secondScore = yourScore [a];
						 topScore;
					 }
			
			  if (yourScore [a] < secondScore && yourScore [a]>thirdScore){
						 thirdScore = yourScore [a];
						 secondScore;
						 topScore;
					 }
				
					 
					 if (yourScore [a] > topScore && yourScore [a] > secondScore && yourScore [a]>thirdScore){
						 thirdScore = secondScore;
						 secondScore = topScore;
						 topScore = yourScore [a];
					 }
					 
					 else {
						 thirdScore;
						 secondScore;
						 topScore;
					 }
		
		//console.log ("top score " + topScore);
		//console.log ("second score " + secondScore);
		//console.log ("third score " + thirdScore);
		}
			
			
			gameoverS.yourScore2.text = String(p);
			gameoverS.highScore2.text = topScore;
		    gameoverS.twoScore2.text = secondScore;
		    gameoverS.threeScore2.text = thirdScore;  
			gameoverS.btnRestart2.addEventListener("click", newGame);
		}
		
		//restart game
		function newGame (){
			init ();
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);
// library properties:
lib.properties = {
	id: '5072016B23554499B8541BC2C3FDD437',
	width: 800,
	height: 600,
	fps: 12,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/PF1Asg02_S10196284_Venus_atlas_.png?1564505008207", id:"PF1Asg02_S10196284_Venus_atlas_"},
		{src:"images/PF1Asg02_S10196284_Venus_atlas_2.png?1564505008207", id:"PF1Asg02_S10196284_Venus_atlas_2"},
		{src:"images/PF1Asg02_S10196284_Venus_atlas_3.png?1564505008207", id:"PF1Asg02_S10196284_Venus_atlas_3"},
		{src:"images/PF1Asg02_S10196284_Venus_atlas_4.png?1564505008207", id:"PF1Asg02_S10196284_Venus_atlas_4"},
		{src:"images/PF1Asg02_S10196284_Venus_atlas_5.png?1564505008207", id:"PF1Asg02_S10196284_Venus_atlas_5"},
		{src:"images/PF1Asg02_S10196284_Venus_atlas_6.png?1564505008208", id:"PF1Asg02_S10196284_Venus_atlas_6"},
		{src:"images/PF1Asg02_S10196284_Venus_atlas_7.png?1564505008208", id:"PF1Asg02_S10196284_Venus_atlas_7"},
		{src:"images/PF1Asg02_S10196284_Venus_atlas_8.png?1564505008208", id:"PF1Asg02_S10196284_Venus_atlas_8"},
		{src:"images/PF1Asg02_S10196284_Venus_atlas_9.png?1564505008208", id:"PF1Asg02_S10196284_Venus_atlas_9"},
		{src:"images/PF1Asg02_S10196284_Venus_atlas_10.png?1564505008208", id:"PF1Asg02_S10196284_Venus_atlas_10"},
		{src:"images/PF1Asg02_S10196284_Venus_atlas_11.png?1564505008208", id:"PF1Asg02_S10196284_Venus_atlas_11"},
		{src:"images/PF1Asg02_S10196284_Venus_atlas_12.png?1564505008208", id:"PF1Asg02_S10196284_Venus_atlas_12"},
		{src:"images/PF1Asg02_S10196284_Venus_atlas_13.png?1564505008208", id:"PF1Asg02_S10196284_Venus_atlas_13"},
		{src:"images/PF1Asg02_S10196284_Venus_atlas_14.png?1564505008208", id:"PF1Asg02_S10196284_Venus_atlas_14"},
		{src:"images/PF1Asg02_S10196284_Venus_atlas_15.png?1564505008208", id:"PF1Asg02_S10196284_Venus_atlas_15"},
		{src:"images/PF1Asg02_S10196284_Venus_atlas_16.png?1564505008208", id:"PF1Asg02_S10196284_Venus_atlas_16"},
		{src:"images/PF1Asg02_S10196284_Venus_atlas_17.png?1564505008208", id:"PF1Asg02_S10196284_Venus_atlas_17"},
		{src:"images/PF1Asg02_S10196284_Venus_atlas_18.png?1564505008208", id:"PF1Asg02_S10196284_Venus_atlas_18"},
		{src:"images/PF1Asg02_S10196284_Venus_atlas_19.png?1564505008208", id:"PF1Asg02_S10196284_Venus_atlas_19"},
		{src:"images/PF1Asg02_S10196284_Venus_atlas_20.png?1564505008208", id:"PF1Asg02_S10196284_Venus_atlas_20"},
		{src:"images/PF1Asg02_S10196284_Venus_atlas_21.png?1564505008208", id:"PF1Asg02_S10196284_Venus_atlas_21"},
		{src:"images/PF1Asg02_S10196284_Venus_atlas_22.png?1564505008210", id:"PF1Asg02_S10196284_Venus_atlas_22"},
		{src:"sounds/siren.mp3?1564505008296", id:"siren"},
		{src:"sounds/breathe.mp3?1564505008296", id:"breathe"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['5072016B23554499B8541BC2C3FDD437'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;